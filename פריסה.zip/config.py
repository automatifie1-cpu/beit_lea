
#Google sheets configuration
APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxarYzowDTUn40WNahypMaTOpjCWz4drmdV2wCvkyYlSNUZgur4pBCoiK0dSU4jTZip/exec"
# Firebase Configuration
KEY_PATH = 'beit-leah-soldiers-firebase-adminsdk-fbsvc-6f3f1f15fb.json'

# WhatsApp API Configuration
WHATSAPP_TOKEN = "YOUR_WHATSAPP_TOKEN_HERE"
PHONE_NUMBER_ID = "YOUR_PHONE_NUMBER_ID_HERE"  
BOT_PHONE_NUMBER = "+YOUR_BOT_PHONE_NUMBER_HERE"
VERIFY_TOKEN = "YOUR_VERIFY_TOKEN_HERE"

# Beit Leah URL
BEIT_LEAH_URL = "https://docs.google.com/forms/d/e/1FAIpQLSfufSxNBjrfO0FPPl7r2g9SXhPhB1KX65BJFdmm7eBCev8wfQ/viewform"