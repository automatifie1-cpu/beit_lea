
#Google sheets configuration
APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxarYzowDTUn40WNahypMaTOpjCWz4drmdV2wCvkyYlSNUZgur4pBCoiK0dSU4jTZip/exec"
# Firebase Configuration
KEY_PATH = 'beit-leah-soldiers-firebase-adminsdk-fbsvc-6f3f1f15fb.json'

# WhatsApp API Configuration
WHATSAPP_TOKEN = "EAApZAR0f6FtABQEszOH7JhqoLZAsnpcZAhIZBBZAoNQHRXN2tkJ2eqlt1ZBftdjlIr1ZBYxfBCG3kznGsMMRbQTkU3MKE7JpuPGlZBaJtRP8PaOBQlGyt8qf0EyLUX4CbmNUu9iRWTvDmnfv9BK06nUo6LmVgJtoivuoYKiKE7dl8S6WI6EKlVCXGvRLu2a270eGLAZDZD"
PHONE_NUMBER_ID = "948193088373337"  
BOT_PHONE_NUMBER = "+1 555 608 3075"
VERIFY_TOKEN = "YOUR_VERIFY_TOKEN_HERE"

# Beit Leah URL
BEIT_LEAH_URL = "https://docs.google.com/forms/d/e/1FAIpQLSfufSxNBjrfO0FPPl7r2g9SXhPhB1KX65BJFdmm7eBCev8wfQ/viewform"